var camera, scene, renderer;
var cameraControls;
var clock = new THREE.Clock();
var ambientLight, light;


function init() {
	var canvasWidth = window.innerWidth * 0.9;
	var canvasHeight = window.innerHeight * 0.9;

	// CAMERA

	camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 80000);
	camera.position.set(-1, 1, 3);
	camera.lookAt(0, 0, 0);

	// LIGHTS

	light = new THREE.DirectionalLight(0xFFFFFF, 0.7);
	light.position.set(1, 1, 1);
	light.target.position.set(0, 0, 0);
	light.target.updateMatrixWorld()

	var ambientLight = new THREE.AmbientLight(0x111111);

	// RENDERER
	renderer = new THREE.WebGLRenderer({ antialias: true });
	renderer.setSize(canvasWidth, canvasHeight);
	renderer.setClearColor(0x454545, 1.0);

	renderer.gammaInput = true;
	renderer.gammaOutput = true;

	// Add to DOM
	var container = document.getElementById('container');
	container.appendChild(renderer.domElement);

	// CONTROLS
	cameraControls = new THREE.OrbitControls(camera, renderer.domElement);
	cameraControls.target.set(0, 0, 0);

	// OBJECTS
	// STAR
	var star = new THREE.Geometry();
	star.vertices.push(new THREE.Vector3(0, 0, 0.1));
	star.vertices.push(new THREE.Vector3(0, 0, -0.1));
	star.vertices.push(new THREE.Vector3(-0.1, 0.1, 0));
	star.vertices.push(new THREE.Vector3(0, 0.3, 0));
	star.vertices.push(new THREE.Vector3(0.1, 0.1, 0));
	star.vertices.push(new THREE.Vector3(0.3, 0, 0));
	star.vertices.push(new THREE.Vector3(0.1, -0.1, 0));
	star.vertices.push(new THREE.Vector3(0, -0.3, 0));
	star.vertices.push(new THREE.Vector3(-0.1, -0.1, 0));
	star.vertices.push(new THREE.Vector3(-0.3, 0, 0));

	star.faces.push(new THREE.Face3(3, 2, 0));
	star.faces.push(new THREE.Face3(4, 3, 0));
	star.faces.push(new THREE.Face3(1, 2, 3));
	star.faces.push(new THREE.Face3(1, 3, 4));

	star.faces.push(new THREE.Face3(5, 4, 0));
	star.faces.push(new THREE.Face3(6, 5, 0));
	star.faces.push(new THREE.Face3(1, 4, 5));
	star.faces.push(new THREE.Face3(1, 5, 6));

	star.faces.push(new THREE.Face3(7, 6, 0));
	star.faces.push(new THREE.Face3(8, 7, 0));
	star.faces.push(new THREE.Face3(1, 7, 8));
	star.faces.push(new THREE.Face3(1, 6, 7));

	star.faces.push(new THREE.Face3(9, 8, 0));
	star.faces.push(new THREE.Face3(2, 9, 0));
	star.faces.push(new THREE.Face3(1, 9, 2));
	star.faces.push(new THREE.Face3(1, 8, 9));

	star.computeFaceNormals();
	var objetostar = new THREE.Mesh(star, new THREE.MeshBasicMaterial({ color: 0xFFFA00 }));

	objetostar.translateX(0);
	objetostar.translateY(1);
	objetostar.translateZ(0);
	objetostar.scale.set(0.5, 0.5, 0.5);

	// BASE
	var base = new THREE.Geometry();
	var ob = -1.2;
	base.vertices.push(new THREE.Vector3(-0.1, ob, 0.1));
	base.vertices.push(new THREE.Vector3(0.1, ob, 0.1));
	base.vertices.push(new THREE.Vector3(0.1, ob, -0.1));
	base.vertices.push(new THREE.Vector3(-0.1, ob, -0.1));
	base.vertices.push(new THREE.Vector3(0, -0.28, 0));

	base.faces.push(new THREE.Face3(1, 4, 0));
	base.faces.push(new THREE.Face3(0, 4, 3));
	base.faces.push(new THREE.Face3(3, 4, 2));
	base.faces.push(new THREE.Face3(2, 4, 1));
	base.faces.push(new THREE.Face3(1, 0, 3));
	base.faces.push(new THREE.Face3(3, 2, 1));

	base.computeFaceNormals();
	var objetobase = new THREE.Mesh(base, new THREE.MeshPhongMaterial({ color: 0xAA5500 }));

	// PISO
	var piso = new THREE.Geometry();
	piso.vertices.push(new THREE.Vector3(-0.1, ob, 0.1));
	piso.vertices.push(new THREE.Vector3(0.1, ob, 0.1));
	piso.vertices.push(new THREE.Vector3(0.1, ob, -0.1));
	piso.vertices.push(new THREE.Vector3(-0.1, ob, -0.1));

	piso.faces.push(new THREE.Face3(3, 0, 1));
	piso.faces.push(new THREE.Face3(1, 2, 3));

	piso.computeFaceNormals();
	var objetopiso = new THREE.Mesh(piso, new THREE.MeshPhongMaterial({ color: 0x99FF22 }));

	objetopiso.translateX(0);
	objetopiso.translateY(0);
	objetopiso.translateZ(0);
	objetopiso.scale.set(60, 1, 60);

	// RAMAS
	var ramas = new THREE.Geometry();
	ramas.vertices.push(new THREE.Vector3(0.7, -0.3, 0.0));
	ramas.vertices.push(new THREE.Vector3(0.0, -0.3, 0.7));
	ramas.vertices.push(new THREE.Vector3(-0.7, -0.3, 0.0));	
	ramas.vertices.push(new THREE.Vector3(0.0, -0.3, -0.7));	
	ramas.vertices.push(new THREE.Vector3(0.0, 0.5, 0.0));	

	ramas.vertices.push(new THREE.Vector3(0.5, 0.3, 0));	
	ramas.vertices.push(new THREE.Vector3(0.0, 0.3, 0.5));	
	ramas.vertices.push(new THREE.Vector3(-0.5, 0.3, 0));	
	ramas.vertices.push(new THREE.Vector3(0.0, 0.3, -0.5));	
	ramas.vertices.push(new THREE.Vector3(0.0, 0.7, 0));	

	ramas.vertices.push(new THREE.Vector3(0.3, 0.6, 0));
	ramas.vertices.push(new THREE.Vector3(0.0, 0.6, 0.3));
	ramas.vertices.push(new THREE.Vector3(-0.3, 0.6, 0));
	ramas.vertices.push(new THREE.Vector3(0.0, 0.6, -0.3));
	ramas.vertices.push(new THREE.Vector3(0.0, 0.9, 0));

	for (let i = 0; i < 3; i++) {
		ramas.faces.push(new THREE.Face3(0 + (5 * i), 1 + (5 * i), 4 + (5 * i)));
		ramas.faces.push(new THREE.Face3(1 + (5 * i), 2 + (5 * i), 4 + (5 * i)));
		ramas.faces.push(new THREE.Face3(2 + (5 * i), 3 + (5 * i), 4 + (5 * i)));
		ramas.faces.push(new THREE.Face3(3 + (5 * i), 0 + (5 * i), 4 + (5 * i)));
		ramas.faces.push(new THREE.Face3(0 + (5 * i), 2 + (5 * i), 1 + (5 * i)));
		ramas.faces.push(new THREE.Face3(0 + (5 * i), 3 + (5 * i), 2 + (5 * i)));
	}

	var material_ramas = new THREE.MeshPhongMaterial({ color: 0x006600 });
	var objeto_ramas = new THREE.Mesh(ramas, material_ramas);


	//COPOS

	var numCopos = 500;
	var l = 20;

	var copos = [];
	for (let i = 0; i < numCopos; i++) {
		copos.push(new THREE.SphereGeometry(0.01, 6, 12));
	}

	var ocopos = [];
	for (let i = 0; i < numCopos; i++) {
		ocopos.push(new THREE.Mesh(copos[i], new THREE.MeshBasicMaterial({ color: 0xFFFFFF })));
	}

	//sphere object
	for (let i = 0; i < numCopos; i++) {
		copos[i].computeFaceNormals();
		ocopos[i].translateX((Math.random()*l)/10-(Math.random()*l)/10);
		ocopos[i].translateY((Math.random()*l)/10-(Math.random()*l)/10);
		ocopos[i].translateZ((Math.random()*l)/10-(Math.random()*l)/10);
	}


	var a_col = [];
	a_col.push(0xff0000);
	a_col.push(0x00ff00);
	a_col.push(0x0000ff);
	a_col.push(0xff00aa);
	a_col.push(0xaaff00);
	a_col.push(0x00aaff);
	a_col.push(0xff0099);
	a_col.push(0x99ff00);
	a_col.push(0x0099ff);

	var sphere1 = new THREE.SphereGeometry(0.06, 64, 32);
	sphere1.computeFaceNormals();
	var objetosphere1 = new THREE.Mesh(sphere1, new THREE.MeshBasicMaterial({ color: a_col[0] }));
	objetosphere1.translateX(0.2);
	objetosphere1.translateY(0.3);
	objetosphere1.translateZ(0.3);

	var sphere2 = new THREE.SphereGeometry(0.06, 64, 32);
	sphere2.computeFaceNormals();
	var objetosphere2 = new THREE.Mesh(sphere2, new THREE.MeshBasicMaterial({ color: a_col[1] }));
	objetosphere2.translateX(-0.2);
	objetosphere2.translateY(0.1);
	objetosphere2.translateZ(-0.1);


	var sphere3 = new THREE.SphereGeometry(0.06, 64, 32);
	sphere3.computeFaceNormals();
	var objetosphere3 = new THREE.Mesh(sphere3, new THREE.MeshBasicMaterial({ color: a_col[2] }));
	objetosphere3.translateX(0.2);
	objetosphere3.translateY(0.1);
	objetosphere3.translateZ(-0.2);

	var sphere4 = new THREE.SphereGeometry(0.06, 64, 32);
	sphere4.computeFaceNormals();
	var objetosphere4 = new THREE.Mesh(sphere4, new THREE.MeshBasicMaterial({ color: a_col[3] }));
	objetosphere4.translateX(-0.4);
	objetosphere4.translateY(0.3);
	objetosphere4.translateZ(0.1);

	var sphere5 = new THREE.SphereGeometry(0.06, 64, 32);
	sphere5.computeFaceNormals();
	var objetosphere5 = new THREE.Mesh(sphere5, new THREE.MeshBasicMaterial({ color: a_col[4] }));
	objetosphere5.translateX(0.3);
	objetosphere5.translateY(0.4);
	objetosphere5.translateZ(-0.1);

	var sphere6 = new THREE.SphereGeometry(0.06, 64, 32);
	sphere6.computeFaceNormals();
	var objetosphere6 = new THREE.Mesh(sphere6, new THREE.MeshBasicMaterial({ color: a_col[5] }));
	objetosphere6.translateX(-0.1);
	objetosphere6.translateY(0.3);
	objetosphere6.translateZ(-0.4);

	var sphere7 = new THREE.SphereGeometry(0.06, 64, 32);
	sphere7.computeFaceNormals();
	var objetosphere7 = new THREE.Mesh(sphere7, new THREE.MeshBasicMaterial({ color: a_col[6] }));
	objetosphere7.translateX(-0.2);
	objetosphere7.translateY(0.3);
	objetosphere7.translateZ(0.3);

	var sphere8 = new THREE.SphereGeometry(0.06, 64, 32);
	sphere8.computeFaceNormals();
	var objetosphere8 = new THREE.Mesh(sphere8, new THREE.MeshBasicMaterial({ color: a_col[7] }));
	objetosphere8.translateX(0.1);
	objetosphere8.translateY(0);
	objetosphere8.translateZ(0.5);



	// SCENE
	scene = new THREE.Scene();
	scene.add(light);
	scene.add(ambientLight);
	scene.add(objetostar);
	scene.add(objetobase);
	scene.add(objetopiso);

	for (let i = 0; i < numCopos; i++) {
		scene.add(ocopos[i]);
	}

	scene.add(objetosphere1);
	scene.add(objetosphere2);
	scene.add(objetosphere3);
	scene.add(objetosphere4);
	scene.add(objetosphere5);
	scene.add(objetosphere6);
	scene.add(objetosphere7);
	scene.add(objetosphere8);

	scene.add(objeto_ramas);

}

function animate() {
	window.requestAnimationFrame(animate);
	render();
}

function render() {
	var delta = clock.getDelta();
	cameraControls.update(delta);
	renderer.render(scene, camera);
}

try {
	init();
	animate();
} catch (e) {
	var errorReport = "Your program encountered an unrecoverable error, can not draw on canvas. Error was:<br/><br/>";
	$('#container').append(errorReport + e);
}
