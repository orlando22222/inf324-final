<?php
include 'conexion.php';

$pdo = new Conexion();

//Listar registros y consultar registro
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
	if (isset($_GET["id"])) {
		$sqlp = "SELECT * FROM alumno WHERE id=:id";
		$sql = $pdo->prepare($sqlp);
		$sql->bindValue(':id', $_GET["id"]);
		$sql->execute();
		$sql->setFetchMode(PDO::FETCH_ASSOC);
		echo json_encode($sql->fetchAll());
		header("HTTP/1.1 200 HAY DATOS");
		exit;
	} else {
		$sqlp = "SELECT * FROM alumno";
		$sql = $pdo->prepare($sqlp);
		$sql->execute();
		$sql->setFetchMode(PDO::FETCH_ASSOC);
		echo json_encode($sql->fetchAll());
		header("HTTP/1.1 200 HAY DATOS");
		exit;
	}
}

//Insertar registro
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	$sqlp = "INSERT INTO alumno (nombre, paterno, materno, matricula, email) VALUES(:nombre,:paterno,:materno,:matricula,:email)";
	$sql = $pdo->prepare($sqlp);
	$sql->bindValue(':nombre', $_GET["nombre"]);
	$sql->bindValue(':paterno', $_GET["paterno"]);
	$sql->bindValue(':materno', $_GET["materno"]);
	$sql->bindValue(':matricula', $_GET["matricula"]);
	$sql->bindValue(':email', $_GET["email"]);
	$sql->execute();
	$idPost = $pdo->lastInsertId();

	if($idPost){
		header("HTTP/1.1 200 ejecucion correcta");
		echo json_encode('REGISTRO AÑADIDO EXITOSAMENTE');
		echo json_encode($idPost);
		exit;
	}else{
		header("HTTP/1.1 400 PETICION ERRONEA");
		exit;
	}
}

if ($_SERVER['REQUEST_METHOD'] == 'PUT') {
	$sqlp = "UPDATE alumno SET nombre=:nombre, paterno=:paterno, materno=:materno, matricula=:matricula, email=:email WHERE id=:id";
	$sql = $pdo->prepare($sqlp);
	$sql->bindValue(':id', $_GET["id"]);
	$sql->bindValue(':nombre', $_GET["nombre"]);
	$sql->bindValue(':paterno', $_GET["paterno"]);
	$sql->bindValue(':materno', $_GET["materno"]);
	$sql->bindValue(':matricula', $_GET["matricula"]);
	$sql->bindValue(':email', $_GET["email"]);
	$sql->execute();
	echo json_encode('REGISTRO ACTUALIZADO CON EXITO');
	header("HTTP/1.1 200 EJECUCION CORRECTA");
	exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
	$sqlp = "DELETE FROM alumno WHERE id=:id";
	$sql = $pdo->prepare($sqlp);
	$sql->bindValue(':id', $_GET["id"]);
	$sql->execute();
	echo json_encode('REGISTRO ELIMINADO CON EXITO');
	header("HTTP/1.1 200 EJECUCION CORRECTA");
	exit;
}

header("HTTP/1.1 400 PETICION ERRONEA");
